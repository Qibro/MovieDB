package org.m_ibrahim.movie.di

import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module
import org.m_ibrahim.movie.core.domain.usecase.MovieInteractor
import org.m_ibrahim.movie.core.domain.usecase.MovieUseCase
import org.m_ibrahim.movie.detail.DetailMovieViewModel
import org.m_ibrahim.movie.home.HomeViewModel

val useCaseModule = module {
    factory<MovieUseCase> { MovieInteractor(get()) }
}
val viewModelModule = module {
    viewModel { HomeViewModel(get()) }
    viewModel { DetailMovieViewModel(get()) }
}
