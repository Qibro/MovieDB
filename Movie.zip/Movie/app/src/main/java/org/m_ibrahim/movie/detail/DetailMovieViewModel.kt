package org.m_ibrahim.movie.detail

import androidx.lifecycle.ViewModel
import org.m_ibrahim.movie.core.domain.model.Movie
import org.m_ibrahim.movie.core.domain.usecase.MovieUseCase

class DetailMovieViewModel(private val movieUseCase: MovieUseCase) : ViewModel() {
    fun setFavoriteMovie(movie: Movie, newStatus:Boolean) = movieUseCase.setFavoriteMovie(movie, newStatus)
}

