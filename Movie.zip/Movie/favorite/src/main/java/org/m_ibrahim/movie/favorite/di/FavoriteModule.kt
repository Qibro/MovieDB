package org.m_ibrahim.movie.favorite.di

import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

val favoriteModule = module {
    viewModel { org.m_ibrahim.movie.favorite.FavoriteViewModel(get()) }
}
