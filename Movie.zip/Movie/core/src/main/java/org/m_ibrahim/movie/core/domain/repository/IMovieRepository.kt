package org.m_ibrahim.movie.core.domain.repository

import androidx.lifecycle.LiveData
import kotlinx.coroutines.flow.Flow
import org.m_ibrahim.movie.core.data.Resource
import org.m_ibrahim.movie.core.domain.model.Movie

interface IMovieRepository {
    fun getAllMovie(): Flow<Resource<List<Movie>>>

    fun getFavoriteMovie(): Flow<List<Movie>>

    fun setFavoriteMovie(movie: Movie, state: Boolean)

}