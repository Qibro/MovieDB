package org.m_ibrahim.movie.core.data.source.local

import androidx.lifecycle.LiveData
import kotlinx.coroutines.flow.Flow
import org.m_ibrahim.movie.core.data.source.local.entity.MovieEntity
import org.m_ibrahim.movie.core.data.source.local.room.MovieDao

class LocalDataSource(private val movieDao: MovieDao) {

    fun getAllMovie(): Flow<List<MovieEntity>> = movieDao.getAllMovie()

    fun getFavoriteMovie(): Flow<List<MovieEntity>> = movieDao.getFavoriteMovie()

    suspend fun insertMovie(movieList: List<MovieEntity>) = movieDao.insertMovie(movieList)

    fun setFavoriteMovie(movie: MovieEntity, newState: Boolean) {
        movie.isFavorite = newState
        movieDao.updateFavoriteMovie(movie)
    }
}