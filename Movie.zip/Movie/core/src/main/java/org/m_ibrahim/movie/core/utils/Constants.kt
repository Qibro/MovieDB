package org.m_ibrahim.movie.core.utils

class Constants {
    companion object {
        const val BASE_IMAGE_URL = "https://image.tmdb.org/t/p/w500/"
        const val BASE_URL = "https://api.themoviedb.org/3/"
        const val API_KEY = "181e6b73bd390042e2b326e82e56a94e"
    }
}