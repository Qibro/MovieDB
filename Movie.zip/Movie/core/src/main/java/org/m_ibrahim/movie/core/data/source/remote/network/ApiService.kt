package org.m_ibrahim.movie.core.data.source.remote.network

import org.m_ibrahim.movie.core.data.source.remote.response.ListMovieResponse
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET("discover/movie?api_key=181e6b73bd390042e2b326e82e56a94e")
    suspend fun getMovies(): ListMovieResponse
}